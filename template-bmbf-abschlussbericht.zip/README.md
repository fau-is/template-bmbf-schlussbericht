# Template für BMBF Abschlussbericht (Software Campus) in LaTeX
